package com.epam.rd.autotasks;


import java.util.ArrayList;

public class TaskCarousel {

    private final ArrayList<Task> tasks = new ArrayList<>();

    private int count = 0;
    private final int countMax;

    public TaskCarousel(int capacity) {
        if (capacity <= 0) {
            throw new UnsupportedOperationException();
        }
        countMax = capacity;
    }

    public boolean addTask(Task task) {
        if (!isFull() && !task.isFinished()) {
            tasks.add(task);
            return true;
        }
        return false;
    }

    public boolean execute() {
        if (isEmpty()) {
            return false;
        }
        isEnd();
        tasks.get(count).execute();
        if (tasks.get(count).isFinished()) {
            tasks.remove(count);
        } else {
            count++;
        }
        return true;
    }

    public boolean isFull() {

        return tasks.size() == countMax;
    }

    public boolean isEmpty() {
        return tasks.isEmpty();
    }

    private void isEnd() {
        if (count >= tasks.size()) {
            count = 0;
        }
    }
}
