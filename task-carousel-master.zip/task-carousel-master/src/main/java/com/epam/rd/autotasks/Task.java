package com.epam.rd.autotasks;

public interface Task {
    void execute();
    boolean isFinished();
}
