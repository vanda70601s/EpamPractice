package com.epam.rd.autotasks.pizzasplit;
import java.util.Scanner;
public class PizzaSplit {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int people = in.nextInt();
        int peace = in.nextInt();
        int pizza = 1;
        int countOfPiec = peace;
        while (people>0) {
            peace=countOfPiec;
            peace*=pizza;
            if (peace%people == 0) {
                break;
            }
            pizza++;
        }
        System.out.println(pizza);


    }
}
