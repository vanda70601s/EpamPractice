package com.epam.rd.autotasks.segments;

import static java.lang.Math.abs;
import static java.lang.Math.sqrt;
import static java.lang.StrictMath.pow;

class Segment {
    private Point start;
    private Point end;

    public Segment(Point start, Point end) {
        this.start = start;
        this.end = end;
        if (start == null || end == null)
            throw new IllegalArgumentException();
        if (start.equals(end))
            throw new IllegalArgumentException();
        if (start.getX() == end.getX() && start.getY() == end.getY()) {
            throw new IllegalArgumentException();

        }
    }

    double length() {
        double xDistanceSquare = Math.pow(start.getX() - end.getX(), 2);
        double yDistanceSquare = Math.pow(start.getY() - end.getY(), 2);
        return Math.sqrt(xDistanceSquare + yDistanceSquare);
    }

    Point middle() {
        return new Point( (start.getX() + end.getX()) / 2,
                (start.getY() + end.getY()) / 2 );
    }

    Point intersection(Segment another) {
        Point start2 = another.start;
        Point end2 = another.end;

        double t = ((((start.getX() - start2.getX()) * (start2.getY() - end2.getY()))
                - ((start.getY() - start2.getY()) * (start2.getX() - end2.getX())))
                / ((((start.getX() - end.getX()) * (start2.getY() - end2.getY()))
                - ((start.getY() - end.getY()) * (start2.getX() - end2.getX())))));

        double u = ((((start.getX() - start2.getX()) * (start.getY() - end.getY()))
                - ((start.getY() - start2.getY()) * (start.getX() - end.getX())))
                / ((((start.getX() - end.getX()) * (start2.getY() - end2.getY()))
                - ((start.getY() - end.getY()) * (start2.getX() - end2.getX())))));

        double x = (start.getX() + t * (end.getX() - start.getX()));
        double y = (start.getY() + t * (end.getY() - start.getY()));

        if (0.0 <= t && t <= 1.0 && 0.0 <= u && u <= 1.0)
        {
            return new Point(x, y);
        }
        else
        {
            return null;
        }





        }
}


